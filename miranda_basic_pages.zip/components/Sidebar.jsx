import React from "react";
import { Link } from "react-router-dom";

export function Sidebar() {
  return (
    <aside className="w-48 bg-gray-900 text-white p-4 space-y-2">
      <div className="text-xl font-bold mb-4">Miranda</div>
      <nav className="flex flex-col space-y-2">
        <Link to="/" className="hover:text-blue-300">Documents</Link>
        <Link to="/buckets" className="hover:text-blue-300">Buckets</Link>
        <Link to="/brainstorm" className="hover:text-blue-300">Brainstorm</Link>
        <Link to="/write" className="hover:text-blue-300">Write</Link>
        <Link to="/exports" className="hover:text-blue-300">Exports</Link>
      </nav>
    </aside>
  );
}