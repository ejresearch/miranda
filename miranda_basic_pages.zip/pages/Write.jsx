import React from "react";
export default function Write() {
  return <div>✍️ Writing Interface</div>;
}