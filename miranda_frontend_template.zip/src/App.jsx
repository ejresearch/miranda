export default function App() {
  return (
    <div className="p-10 text-4xl text-blue-600 font-bold border border-red-500">
      ✅ Tailwind is working!
    </div>
  );
}