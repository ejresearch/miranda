import { BrowserRouter as Router, Routes, Route } from "react-router-dom";
import { Sidebar } from "./components/Sidebar";
import { Topbar } from "./components/Topbar";
import Documents from "./pages/Documents";
import Buckets from "./pages/Buckets";
import Brainstorm from "./pages/Brainstorm";
import Write from "./pages/Write";
import Exports from "./pages/Exports";

export default function App() {
  return (
    <Router>
      <div className="flex h-screen">
        <Sidebar />
        <div className="flex flex-col flex-1">
          <Topbar />
          <main className="p-4 overflow-y-auto flex-1 bg-white">
            <Routes>
              <Route path="/" element={<Documents />} />
              <Route path="/buckets" element={<Buckets />} />
              <Route path="/brainstorm" element={<Brainstorm />} />
              <Route path="/write" element={<Write />} />
              <Route path="/exports" element={<Exports />} />
            </Routes>
          </main>
        </div>
      </div>
    </Router>
  );
}