export function Topbar() {
  return (
    <header className="h-14 bg-gray-100 border-b px-4 flex items-center">
      <h1 className="text-lg font-semibold">Project Dashboard</h1>
    </header>
  );
}