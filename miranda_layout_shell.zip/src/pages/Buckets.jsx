export default function Buckets() {
  return <div>🗂️ Bucket Manager</div>;
}