export default function Documents() {
  return <div>📄 Reference Documents</div>;
}