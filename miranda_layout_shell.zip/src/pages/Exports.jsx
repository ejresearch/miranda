export default function Exports() {
  return <div>📤 Export Manager</div>;
}