import { useEffect, useState } from "react";
import { api } from "../api/client";

export function useTables(projectName) {
  const [tables, setTables] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);

  useEffect(() => {
    async function fetchTables() {
      try {
        setLoading(true);
        const res = await api.get(`/projects/${projectName}/tables`);
        setTables(res.data);
      } catch (err) {
        setError(err);
      } finally {
        setLoading(false);
      }
    }
    fetchTables();
  }, [projectName]);

  return { tables, loading, error };
}