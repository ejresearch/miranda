import React from "react";
import { useTables } from "../hooks/useTables";

export default function Documents() {
  const project = "demo_project"; // Later: pull from context
  const { tables, loading, error } = useTables(project);

  return (
    <div>
      <h2 className="text-xl font-semibold mb-4">📄 Reference Documents</h2>
      {loading && <p className="text-gray-500">Loading tables...</p>}
      {error && <p className="text-red-500">Error: {error.message}</p>}
      <ul className="space-y-1">
        {tables.map((table) => (
          <li key={table} className="border p-2 rounded bg-white shadow">
            {table}
          </li>
        ))}
      </ul>
    </div>
  );
}